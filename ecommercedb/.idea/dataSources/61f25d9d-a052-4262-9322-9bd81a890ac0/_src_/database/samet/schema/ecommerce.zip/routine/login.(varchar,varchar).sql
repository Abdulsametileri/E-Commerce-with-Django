CREATE FUNCTION login (email character varying, pw character varying) RETURNS integer
	LANGUAGE plpgsql
AS $$
DECLARE
	cust_auth integer;
	admin_auth integer;
BEGIN

	SELECT INTO cust_auth a.authorization_level, c.customer_mail, c.customer_password
	FROM ecommerce."Customer" as c
	INNER JOIN ecommerce."Authorization" as a
        ON a.authorization_id = c.customer_auth_id 
	WHERE c.customer_mail = email AND
	      c.customer_password = pw;

	IF cust_auth IS NULL THEN
		SELECT INTO admin_auth auth.authorization_level, a.admin_mail, a.admin_password
		FROM ecommerce."Admin" as a
		INNER JOIN ecommerce."Authorization" as auth
		ON auth.authorization_id = a.admin_auth_id
		WHERE a.admin_mail=email AND a.admin_password=pw;
		
		IF admin_auth IS NULL THEN
			return -1;
		ELSE
			return admin_auth;
		END IF;
	ELSE
		return cust_auth;
	END IF;
END


$$
