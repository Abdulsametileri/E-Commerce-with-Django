CREATE TRIGGER "updateStock"
AFTER INSERT ON ecommerce."Order"
FOR EACH ROW EXECUTE PROCEDURE ecommerce."updateStock"()