CREATE FUNCTION getproductbysubcatid (subcat_id integer) RETURNS TABLE(product_id integer, product_name character varying, product_description character varying, product_url character varying, product_viewed integer, product_price numeric, product_stock integer)
	LANGUAGE plpgsql
AS $$
BEGIN
	RETURN QUERY SELECT product_id, product_name, product_description, product_url, product_viewed, product_price, product_stock
	FROM ecommerce."Product"
	WHERE product_id = subcat_id;
END

$$
