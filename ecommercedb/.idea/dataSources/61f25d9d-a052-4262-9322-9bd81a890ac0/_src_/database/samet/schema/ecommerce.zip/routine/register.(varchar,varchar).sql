CREATE FUNCTION register (email character varying, pw character varying) RETURNS integer
	LANGUAGE plpgsql
AS $$
DECLARE
	op_result integer;
BEGIN
	INSERT INTO ecommerce."Customer"(customer_mail, customer_password)
	VALUES (email,pw) RETURNING customer_id into op_result;

	RETURN op_result;
END
$$
