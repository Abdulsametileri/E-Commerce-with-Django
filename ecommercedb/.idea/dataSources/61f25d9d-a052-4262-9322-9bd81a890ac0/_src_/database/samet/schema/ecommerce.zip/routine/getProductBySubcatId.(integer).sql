CREATE FUNCTION getProductBySubcatId (subcat_id integer) RETURNS TABLE(product_subcat_id integer, product_name character varying, product_description character varying, product_url character varying, product_viewed integer, product_price numeric, product_stock integer, product_id integer)
	LANGUAGE plpgsql
AS $$
BEGIN
	RETURN QUERY SELECT
	p.product_subcat_id, p.product_name, p.product_description, 
	p.product_url, p.product_viewed, p.product_price, p.product_stock,
	p.product_id
	FROM ecommerce."Product" as p
	WHERE p.product_subcat_id = subcat_id;
END
$$
