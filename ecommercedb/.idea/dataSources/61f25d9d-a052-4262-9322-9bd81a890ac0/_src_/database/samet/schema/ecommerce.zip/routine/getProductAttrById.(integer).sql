CREATE FUNCTION getProductAttrById (prod_id integer) RETURNS TABLE(attribute_name character varying, val character varying)
	LANGUAGE plpgsql
AS $$
BEGIN
	RETURN QUERY SELECT c.attribute_name, p.val
	FROM ecommerce."ProductAttribute" as p
	INNER JOIN ecommerce."ProductComAttr" as c 
	ON p.attribute_id = c.id
	WHERE p.product_id = prod_id;
END
$$
