CREATE FUNCTION insert_customer (customer_fname character varying, customer_lname character varying, customer_email character varying, customer_password character varying, customer_address character varying, customer_phone character varying) RETURNS void
	LANGUAGE plpgsql
AS $$
DECLARE passed BOOLEAN;
BEGIN
        INSERT INTO Phone ("Phone_no") VALUES (customer_phone);
END;
$$
