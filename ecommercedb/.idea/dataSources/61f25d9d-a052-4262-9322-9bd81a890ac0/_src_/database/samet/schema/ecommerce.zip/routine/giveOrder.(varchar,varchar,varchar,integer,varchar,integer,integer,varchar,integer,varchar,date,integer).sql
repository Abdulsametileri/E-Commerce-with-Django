CREATE FUNCTION giveOrder (fname character varying, lname character varying, address character varying, phone integer, card_name character varying, card_number integer, card_cvc integer, email character varying, piece integer, carg_name character varying, given_date date, product_id integer) RETURNS integer
	LANGUAGE plpgsql
AS $$
DECLARE
	op_result integer; --operation result
	p_id integer; --phone id 
	a_id integer; --address_id
	c_id integer; --cargo_id
	card_id integer; 
	stockControl integer;
BEGIN

	INSERT INTO ecommerce."Phone"(phone_no) VALUES (phone) 
		RETURNING phone_id into p_id; 
	INSERT INTO ecommerce."Address"(address_full) VALUES (address) 
		RETURNING address_id into a_id;
	-- Check Cargo A Cargo or B Cargo? Başka olamaz Business Rule böyle

	IF carg_name <> 'A Cargo' THEN
		c_id = 1;
	ELSE
		c_id = 2;
	END IF;
		
	INSERT INTO ecommerce."CreditCard"("CardNumber", "CardHolderName", "CardCVC")
		VALUES (card_number, card_name, card_cvc)
		RETURNING card_number into card_id;

	INSERT INTO ecommerce."Order"(
		    order_given_date, order_piece, 
		    order_status, order_cargo_id, order_product_id, order_address_id, 
		    order_creditcard_id, order_phone_id)
		VALUES (given_date, piece, 
		    'Cargo was given', c_id, product_id, a_id, 
		    card_id, p_id)
		RETURNING order_id into op_result;
	
	UPDATE ecommerce."Customer" 
	SET customer_fname=fname, customer_lname=lname, customer_order_id=op_result
	WHERE customer_mail = email;

	RETURN op_result;

END
$$
