CREATE FUNCTION phone_insert (phone_no integer) RETURNS void
	LANGUAGE plpgsql
AS $$
BEGIN
	INSERT INTO Phone ("phone_no") VALUES (phone_no);
END;
$$
