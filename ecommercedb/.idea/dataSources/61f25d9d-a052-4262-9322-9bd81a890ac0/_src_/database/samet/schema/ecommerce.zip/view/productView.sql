CREATE VIEW "productView" AS
SELECT p.product_subcat_id,
    p.product_name,
    p.product_description,
    p.product_url,
    p.product_viewed,
    p.product_price,
    p.product_stock,
    p.product_id
   FROM ecommerce."Product" p
  ORDER BY (random())
 LIMIT 9