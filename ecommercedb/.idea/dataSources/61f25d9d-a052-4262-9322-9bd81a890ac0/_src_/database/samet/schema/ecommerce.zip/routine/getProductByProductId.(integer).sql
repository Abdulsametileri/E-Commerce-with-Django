CREATE FUNCTION getProductByProductId (prod_id integer) RETURNS TABLE(product_name character varying, product_description character varying, product_url character varying, product_viewed integer, product_price numeric, product_stock integer)
	LANGUAGE plpgsql
AS $$
DECLARE
	prod_view_new integer;

BEGIN

	SELECT INTO prod_view_new p.product_viewed FROM ecommerce."Product" as p
	WHERE p.product_id = prod_id;
	
	prod_view_new = prod_view_new + 1;

	UPDATE ecommerce."Product" 
	SET product_viewed=prod_view_new
	WHERE product_id = prod_id;

	RETURN QUERY SELECT 
	p.product_name, p.product_description, p.product_url, 
	p.product_viewed, p.product_price, p.product_stock
	FROM ecommerce."Product" as p
	WHERE p.product_id = prod_id;

END
--TABLE(product_name character varying, product_description character varying, product_url character varying, product_viewed integer, product_price numeric, product_stock integer)

$$
