CREATE FUNCTION insertProduct (pname character varying, pdescr character varying, purl character varying, pprice numeric, pstock integer, psubcatid integer) RETURNS void
	LANGUAGE plpgsql
AS $$
BEGIN


            INSERT INTO ecommerce."Product"(
            product_name, product_description, product_url, 
            product_price, product_stock, product_subcat_id)
            VALUES (pname, pdescr, purl, 
            pprice, pstock, psubcatid);





END
$$
