CREATE FUNCTION updatestock () RETURNS trigger
	LANGUAGE plpgsql
AS $$
DECLARE
	prod_stock_new integer; --product_id
BEGIN
	SELECT product_stock into prod_stock_new FROM ecommerce."Product" WHERE product_id = OLD.order_product_id;
	prod_stock_new = prod_stock_new - 1;
	UPDATE ecommerce."Product" SET product_stock=prod_stock_new WHERE product_id = OLD.order_product_id;
END;
$$
