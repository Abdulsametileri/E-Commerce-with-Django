CREATE FUNCTION updateStock () RETURNS trigger
	LANGUAGE plpgsql
AS $$
DECLARE
	prod_stock_new integer; --product_id
BEGIN
	SELECT INTO prod_stock_new product_stock FROM ecommerce."Product" 
		WHERE product_id = NEW.order_product_id;

	prod_stock_new = prod_stock_new - NEW.order_piece;

	UPDATE ecommerce."Product" SET product_stock=prod_stock_new 
		WHERE product_id = NEW.order_product_id;

	RETURN new;
END;
$$
